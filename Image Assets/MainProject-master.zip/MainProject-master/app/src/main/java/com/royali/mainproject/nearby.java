package com.royali.mainproject;

import android.content.Intent;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.quinny898.library.persistentsearch.SearchBox;
import com.quinny898.library.persistentsearch.SearchResult;

public class nearby extends AppCompatActivity {
public SearchBox search;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_nearby);
        TextView findnearbyTxtView =(TextView)findViewById(R.id.txtviewFindStore);
        findnearbyTxtView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(nearby.this,wallmart.class));




            }
        });
        search = (SearchBox) findViewById(R.id.searchbox);
        search.enableVoiceRecognition(nearby.this);

        for(int x = 0; x < 2; x++){
            SearchResult option = new SearchResult("V5R 2s6 " + Integer.toString(x), getResources().getDrawable(R.drawable.historyicon));
            search.addSearchable(option);
        }

        search.setMenuListener(new SearchBox.MenuListener(){

            @Override
            public void onMenuClick() {
                //Hamburger has been clicked
                Toast.makeText(nearby.this, "Menu click", Toast.LENGTH_LONG).show();
            }

        });
        search.setSearchListener(new SearchBox.SearchListener(){


            @Override
            public void onSearchOpened() {

            }

            @Override
            public void onSearchCleared() {


            }

            @Override
            public void onSearchClosed() {

            }

            @Override
            public void onSearchTermChanged(String s) {

            }

            @Override
            public void onSearch(String s) {

            }

            @Override
            public void onResultClick(SearchResult searchResult) {

startActivity(new Intent(nearby.this,wallmart.class));
            }
        });
    }
}
